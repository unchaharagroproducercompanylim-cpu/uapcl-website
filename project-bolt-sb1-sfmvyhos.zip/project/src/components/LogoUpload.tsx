import React, { useState } from 'react';
import { Upload, X, Check } from 'lucide-react';

interface LogoUploadProps {
  onLogoUpdate: (logoUrl: string) => void;
  currentLogo?: string;
}

const LogoUpload: React.FC<LogoUploadProps> = ({ onLogoUpdate, currentLogo }) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      alert('File size should be less than 5MB');
      return;
    }

    setUploading(true);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreview(result);
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleConfirm = () => {
    if (preview) {
      onLogoUpdate(preview);
      alert('Logo updated successfully! The new logo will appear in the header.');
    }
  };

  const handleRemove = () => {
    setPreview(null);
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-2xl shadow-xl p-8">
      <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Update UAPCL Logo</h3>
      
      {!preview ? (
        <div
          className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
            dragActive 
              ? 'border-green-500 bg-green-50' 
              : 'border-gray-300 hover:border-green-400 hover:bg-green-50'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            disabled={uploading}
          />
          
          <div className="space-y-4">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
              <Upload className="h-8 w-8 text-green-600" />
            </div>
            
            <div>
              <p className="text-lg font-medium text-gray-900 mb-2">
                {uploading ? 'Processing...' : 'Upload Your Logo'}
              </p>
              <p className="text-sm text-gray-600">
                Drag and drop your logo here, or click to browse
              </p>
              <p className="text-xs text-gray-500 mt-2">
                Supports: JPG, PNG, SVG (Max 5MB)
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-gray-50 rounded-xl p-6 text-center">
            <img 
              src={preview} 
              alt="Logo preview" 
              className="max-h-32 mx-auto rounded-lg shadow-md"
            />
          </div>
          
          <div className="flex space-x-4">
            <button
              onClick={handleConfirm}
              className="flex-1 bg-green-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center"
            >
              <Check className="h-5 w-5 mr-2" />
              Use This Logo
            </button>
            
            <button
              onClick={handleRemove}
              className="flex-1 bg-gray-200 text-gray-700 py-3 px-6 rounded-lg font-medium hover:bg-gray-300 transition-colors flex items-center justify-center"
            >
              <X className="h-5 w-5 mr-2" />
              Remove
            </button>
          </div>
        </div>
      )}
      
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-2">Logo Guidelines:</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Use a square or rectangular logo for best results</li>
          <li>• Ensure good contrast for visibility</li>
          <li>• PNG format with transparent background recommended</li>
          <li>• Minimum resolution: 200x200 pixels</li>
        </ul>
      </div>
    </div>
  );
};

export default LogoUpload;