import React from 'react';
import { Link } from 'react-router-dom'; 
import { Leaf, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-green-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-600 p-2 rounded-full">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">UAPCL</h3>
                <p className="text-sm text-green-200">Unchahar Agro Producer Company Limited</p>
              </div>
            </div>
            <p className="text-green-100 mb-4 max-w-md">
              Empowering farmers through sustainable agriculture, modern farming techniques, and comprehensive support systems. Building a stronger agricultural community together.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-green-200 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-green-200 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://www.instagram.com/uapcl_?igsh=MTJqbmtwODA5cHF3cQ==" target="_blank" rel="noopener noreferrer" className="text-green-200 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <nav className="space-y-2">
              <Link to="/" className="block text-green-200 hover:text-white transition-colors">
                Home
              </Link>
              <Link to="/about" className="block text-green-200 hover:text-white transition-colors">
                About Us
              </Link>
              <Link to="/services" className="block text-green-200 hover:text-white transition-colors">
                Services
              </Link>
              <Link to="/gallery" className="block text-green-200 hover:text-white transition-colors">
                Gallery
              </Link>
              <Link to="/contact" className="block text-green-200 hover:text-white transition-colors">
                Contact
              </Link>
            </nav>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-green-400 mt-1 flex-shrink-0" />
                <p className="text-green-200 text-sm">
                  Near Bus Stop Unchahar<br />
                  Reabareli, Uttar Pradesh, India
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-green-400 flex-shrink-0" />
                <p className="text-green-200 text-sm">+91 8127467539</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-green-400 flex-shrink-0" />
                <p className="text-green-200 text-sm">unchaharagroproducercompanylim@gmail.com</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-green-700 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-green-200 text-sm">
              © 2025 Unchahar Agro Producer Company Limited. All rights reserved.
            </p>
            <p className="text-green-200 text-sm mt-2 md:mt-0">
              Established: 31st January 2025
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;