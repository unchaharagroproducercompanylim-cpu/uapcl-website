import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, Leaf, TrendingUp, Award } from 'lucide-react';

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section - CUSTOMIZABLE IMAGE */}
      <section className="relative bg-gradient-to-r from-green-800 to-green-600 text-white">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop)'
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-3xl">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              Empowering Farmers, <br />
              <span className="text-green-700">Growing Together</span>
            </h1>
            <p className="text-xl lg:text-2xl mb-8 text-green-80">
              Unchahar Agro Producer Company Limited - Your trusted partner in sustainable agriculture, post-harvest management, and farmer prosperity.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link
                to="/about"
                className="bg-green-500 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-green-400 transition-colors flex items-center justify-center"
              >
                Learn More <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/contact"
                className="bg-white text-green-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-green-50 transition-colors flex items-center justify-center"
              >
                Join Us Today
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Purpose</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Dedicated to transforming agriculture through innovation, sustainability, and farmer empowerment
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Leaf className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600 text-lg leading-relaxed">
                To empower farmers through comprehensive agricultural services, modern farming techniques, and sustainable practices that enhance productivity, profitability, and environmental stewardship.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-600 text-lg leading-relaxed">
                To be the leading Farmer Producer Organization that creates prosperous farming communities through innovation, collaboration, and sustainable agricultural practices across the region.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Stats */}
      <section className="py-20 bg-green-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Impact</h2>
            <p className="text-xl text-green-100">
              Making a difference in the agricultural community since our establishment
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold mb-2">300+</h3>
              <p className="text-green-100">People Influenced</p>
            </div>

            <div className="text-center">
              <div className="bg-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold mb-2">200</h3>
              <p className="text-green-100">Acres Farming Land Covered</p>
            </div>

            <div className="text-center">
              <div className="bg-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold mb-2">25%</h3>
              <p className="text-green-100">Average Income Increase</p>
            </div>

            <div className="text-center">
              <div className="bg-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold mb-2">50+</h3>
              <p className="text-green-100">Training Programs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600">
              Comprehensive agricultural support for modern farming
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div 
                className="h-48 bg-cover bg-center rounded-xl mb-6"
                style={{
                  backgroundImage: 'url(https://i.postimg.cc/X7h8sJfW/3.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop)'
                }}
              ></div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Post-Harvest Management</h3>
              <p className="text-gray-600 mb-4">
                State-of-the-art storage facilities and processing solutions to minimize post-harvest losses and maximize farmer income.
              </p>
              <Link to="/services" className="text-green-600 font-semibold hover:text-green-700">
                Learn More →
              </Link>
            </div>

            <div className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div 
                className="h-48 bg-cover bg-center rounded-xl mb-6"
                style={{
                  backgroundImage: 'url(https://i.postimg.cc/KvRLdS3d/1.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop)'
                }}
              ></div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Scientific Farming</h3>
              <p className="text-gray-600 mb-4">
                Modern agricultural techniques, soil testing, and scientific cropping methods for enhanced productivity.
              </p>
              <Link to="/services" className="text-green-600 font-semibold hover:text-green-700">
                Learn More →
              </Link>
            </div>

            <div className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div 
                className="h-48 bg-cover bg-center rounded-xl mb-6"
                style={{
                  backgroundImage: 'url(https://i.postimg.cc/cC2R7smL/5.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop)'
                }}
              ></div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Training & Support</h3>
              <p className="text-gray-600 mb-4">
                Comprehensive training programs and ongoing support to help farmers adopt best practices and new technologies.
              </p>
              <Link to="/services" className="text-green-600 font-semibold hover:text-green-700">
                Learn More →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-green-700 to-green-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Transform Your Farming Journey?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Join UAPCL today and become part of a thriving agricultural community dedicated to sustainable growth and prosperity.
          </p>
          <Link
            to="/contact"
            className="bg-white text-green-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-green-50 transition-colors inline-flex items-center"
          >
            Get Started Now <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;