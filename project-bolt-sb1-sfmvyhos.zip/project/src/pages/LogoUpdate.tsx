import React, { useState } from 'react';
import LogoUpload from '../components/LogoUpload';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const LogoUpdate = () => {
  const [logoUpdated, setLogoUpdated] = useState(false);

  const handleLogoUpdate = (logoUrl: string) => {
    // In a real application, you would save this to your backend/database
    // For now, we'll store it in localStorage for demonstration
    localStorage.setItem('uapcl-logo', logoUrl);
    setLogoUpdated(true);
    
    // Trigger a page refresh to show the new logo
    setTimeout(() => {
      window.location.reload();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <div className="mb-8">
          <Link 
            to="/" 
            className="inline-flex items-center text-green-600 hover:text-green-700 font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Home
          </Link>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Update UAPCL Logo</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upload your custom UAPCL logo to personalize your website. The logo will appear in the header across all pages.
          </p>
        </div>

        {/* Logo Upload Component */}
        <div className="flex justify-center">
          <LogoUpload onLogoUpdate={handleLogoUpdate} />
        </div>

        {/* Success Message */}
        {logoUpdated && (
          <div className="mt-8 max-w-md mx-auto">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
              <p className="text-green-800 font-medium">
                ✅ Logo updated successfully! Refreshing page...
              </p>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-12 max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">How to Update Your Logo</h2>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-green-100 text-green-600 rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Prepare Your Logo</h3>
                  <p className="text-gray-600">
                    Create or prepare your UAPCL logo in PNG, JPG, or SVG format. For best results, use a square or rectangular logo with good contrast.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-100 text-green-600 rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Upload Your Logo</h3>
                  <p className="text-gray-600">
                    Drag and drop your logo file into the upload area above, or click to browse and select your file.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-100 text-green-600 rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">
                  3
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Preview and Confirm</h3>
                  <p className="text-gray-600">
                    Review your logo in the preview area, then click "Use This Logo" to apply it to your website header.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-100 text-green-600 rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">
                  4
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">See Your Logo Live</h3>
                  <p className="text-gray-600">
                    Your new logo will appear in the website header immediately. Navigate through the site to see it on all pages.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogoUpdate;