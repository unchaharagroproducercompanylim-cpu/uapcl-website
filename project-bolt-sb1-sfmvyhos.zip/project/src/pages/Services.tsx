import React from 'react';
import { Warehouse, TrendingUp, Users, TestTube, Sprout, BookOpen, Shield, DollarSign } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Warehouse,
      title: 'Post-Harvest Management',
      description: 'State-of-the-art storage facilities and processing solutions to minimize post-harvest losses and maximize farmer income.',
      image: 'https://i.postimg.cc/NF1W3DdB/3.png?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Modern storage facilities', 'Processing equipment', 'Quality control systems', 'Loss prevention measures']
    },
    {
      icon: TrendingUp,
      title: 'Market Linkages',
      description: 'Direct connections to markets, buyers, and supply chains ensuring fair prices and consistent demand for farmer produce.',
      image: 'https://i.postimg.cc/wMKC4Zcw/2.png?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Direct buyer connections', 'Fair price negotiations', 'Supply chain optimization', 'Export opportunities']
    },
    {
      icon: DollarSign,
      title: 'Subsidy Facilitation & DBTs',
      description: 'Comprehensive assistance in accessing government subsidies, schemes, and direct benefit transfers for farmers.',
      image: 'https://i.postimg.cc/7P08JPwd/5.png?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Subsidy application support', 'DBT processing', 'Government scheme access', 'Documentation assistance']
    },
    {
      icon: Sprout,
      title: 'Seed Production',
      description: 'High-quality seed production and distribution services ensuring farmers have access to certified, disease-resistant varieties.',
      image: 'https://images.pexels.com/photos/1459505/pexels-photo-1459505.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Certified seed production', 'Quality assurance', 'Variety selection', 'Seed treatment services']
    },
    {
      icon: Users,
      title: 'Scientific Cropping',
      description: 'Implementation of scientific farming methods, crop rotation, and precision agriculture for enhanced productivity.',
      image: 'https://images.pexels.com/photos/1595385/pexels-photo-1595385.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Precision farming', 'Crop rotation planning', 'Yield optimization', 'Technology integration']
    },
    {
      icon: Shield,
      title: 'Natural Farming',
      description: 'Organic and natural farming practices that promote soil health, biodiversity, and sustainable agricultural systems.',
      image: 'https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Organic certification', 'Natural pest control', 'Composting techniques', 'Biodiversity conservation']
    },
    {
      icon: BookOpen,
      title: 'Training & Awareness',
      description: 'Comprehensive training programs and awareness sessions on modern farming techniques, market trends, and best practices.',
      image: 'https://images.pexels.com/photos/2132177/pexels-photo-2132177.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      features: ['Skill development workshops', 'Technology training', 'Market awareness', 'Best practice sharing']
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-green-600 text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl lg:text-2xl text-green-100 max-w-3xl mx-auto">
              Comprehensive agricultural solutions designed to empower farmers and enhance productivity
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow">
                {/* CUSTOMIZABLE IMAGE */}
                <div 
                  className="h-64 bg-cover bg-center"
                  style={{ backgroundImage: `url(${service.image})` }}
                ></div>
                
                <div className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="bg-green-100 p-3 rounded-full mr-4">
                      <service.icon className="h-6 w-6 text-green-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">{service.title}</h3>
                  </div>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2 flex-shrink-0"></div>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-green-700 to-green-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Access Our Services?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Contact us today to learn more about how UAPCL can support your farming operations and help you achieve greater success.
          </p>
          <a
            href="/contact"
            className="bg-white text-green-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-green-50 transition-colors inline-block"
          >
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;