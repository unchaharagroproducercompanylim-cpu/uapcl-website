import React from 'react';
import { Calendar, Users, Target, Award } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-green-600 text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">About UAPCL</h1>
            <p className="text-xl lg:text-2xl text-green-100 max-w-3xl mx-auto">
              Unchahar Agro Producer Company Limited - Pioneering sustainable agriculture and farmer empowerment since 2025
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Unchahar Agro Producer Company Limited was established on 31st January 2025 with a vision to transform the agricultural landscape in our region. As a Farmer Producer Organization (FPO), we are committed to empowering farmers through innovative solutions, sustainable practices, and comprehensive support systems.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Our organization serves as a bridge between traditional farming wisdom and modern agricultural technology, helping farmers increase their productivity, reduce costs, and access better markets for their produce.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Under the leadership of our CEO, Chairperson & Managing Director Anubhav, we strive to create a sustainable ecosystem that benefits not only our member farmers but the entire agricultural community.
              </p>
            </div>
            
            {/* CUSTOMIZABLE IMAGE */}
            <div className="lg:order-first">
              <div 
                className="h-96 bg-cover bg-center rounded-2xl shadow-xl"
                style={{
                  backgroundImage: 'url(https://i.postimg.cc/1RrXrdNf/logo-uapcl-removebg-preview.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop)'
                }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Registration Details */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Company Details</h2>
              <p className="text-xl text-gray-600">Official registration and organizational information</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-green-50 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <Calendar className="h-8 w-8 text-green-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">Establishment Date</h3>
                </div>
                <p className="text-gray-600">31st January 2025</p>
              </div>

              <div className="bg-green-50 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <Award className="h-8 w-8 text-green-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">Organization Type</h3>
                </div>
                <p className="text-gray-600">Farmer Producer Organization (FPO)</p>
              </div>

              <div className="bg-green-50 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <Users className="h-8 w-8 text-green-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">Leadership</h3>
                </div>
                <p className="text-gray-600">CEO, Chairperson & Managing Director: Anubhav</p>
              </div>

              <div className="bg-green-50 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <Target className="h-8 w-8 text-green-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">Primary Focus</h3>
                </div>
                <p className="text-gray-600">Sustainable Agriculture & Farmer Empowerment</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Leadership</h2>
            <p className="text-xl text-gray-600">Dedicated leaders driving agricultural transformation</p>
          </div>

          <div className="max-w-2xl mx-auto">
            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-2xl p-8 text-center">
              {/* CUSTOMIZABLE IMAGE - Leadership Photo */}
              <div 
                className="w-32 h-32 bg-cover bg-center rounded-full mx-auto mb-6 shadow-lg"
                style={{
                  backgroundImage: 'url(https://i.postimg.cc/htxNDVWb/Whats-App-Image-2025-09-10-at-03-50-52-27e99033.jpg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop)'
                }}
              ></div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Anubhav</h3>
              <p className="text-lg text-green-600 mb-4">CEO, Chairperson & Managing Director</p>
              <p className="text-gray-600 leading-relaxed">
                With a vision to revolutionize agriculture in our region, Anubhav leads UAPCL with passion and dedication. Under his leadership, the organization is committed to implementing innovative farming solutions and empowering farmers through comprehensive support systems.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Organizational Goals */}
      <section className="py-20 bg-gradient-to-r from-green-700 to-green-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Our Goals</h2>
            <p className="text-xl text-green-100">Building a sustainable future for agriculture</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Farmer Empowerment</h3>
              <p className="text-green-100">
                Providing farmers with the tools, knowledge, and resources needed to thrive in modern agriculture.
              </p>
            </div>

            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Sustainable Practices</h3>
              <p className="text-green-100">
                Promoting environmentally friendly farming methods that preserve soil health and biodiversity.
              </p>
            </div>

            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Market Access</h3>
              <p className="text-green-100">
                Creating direct market linkages to ensure farmers get fair prices for their produce.
              </p>
            </div>

            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Technology Integration</h3>
              <p className="text-green-100">
                Introducing modern agricultural technologies to improve efficiency and productivity.
              </p>
            </div>

            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Community Building</h3>
              <p className="text-green-100">
                Fostering strong agricultural communities through collaboration and mutual support.
              </p>
            </div>

            <div className="bg-green-600 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Financial Inclusion</h3>
              <p className="text-green-100">
                Facilitating access to credit, subsidies, and financial services for rural farmers.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;