import React, { useState } from 'react';
import { X } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // CUSTOMIZABLE IMAGES - All images can be easily replaced
  const galleryImages = [
    {
      id: 1,
      src: 'https://i.postimg.cc/7hNPfLRK/2.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Market Linkage',
      category: 'Marketing'
    },
    {
      id: 2,
      src: 'https://i.postimg.cc/vTZzNx2Y/20250424-181913.jpg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Meeting 2025',
      category: 'Meetings'
    },
    {
      id: 3,
      src: 'https://i.postimg.cc/X7h8sJfW/3.png',
      alt: 'Warehouse storage facility',
      category: 'Storage Facilities'
    },
     
    {
      id: 4,
      src: 'https://i.postimg.cc/z3myR9gs/20250710-160352.jpg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Training session with farmers',
      category: 'Training Programs'
    },
    { 
      id: 5,
      src: 'https://i.postimg.cc/jdV6f9tq/20250731-163324.jpg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Internship certificate disribution',
      category: 'Internships'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Natural farming practices',
      category: 'Natural Farming'
    },
    {
      id: 7, 
      src: 'https://i.postimg.cc/KvdBnqpB/Screenshot-2025-09-10-031218.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'CUG Monthly Magazine',
      category: 'Achivements'
    },
    { 
      id: 8,
      src: 'https://i.postimg.cc/mDcg6cMz/Whats-App-Image-2025-09-10-at-03-33-12-6697a6bc.jpg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'UAPCL team members',
      category: 'Team & Leadership'
    },
    {
      id: 9,
      src: 'https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Crop harvesting',
      category: 'Harvesting'
    },
    {
      id: 10,
      src: 'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Processing facilities',
      category: 'Processing'
    },
    {
      id: 11,
      src: 'https://i.postimg.cc/cC2R7smL/5.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Farmer education program',
      category: 'Workshops'
    },
    {
      id: 12,
      src: 'https://i.postimg.cc/KvRLdS3d/1.png?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      alt: 'Sustainable farming techniques',
      category: 'Sustainability'
    }
  ];

  const categories = ['All', ...Array.from(new Set(galleryImages.map(img => img.category)))];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredImages = activeCategory === 'All' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-green-600 text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">Gallery</h1>
            <p className="text-xl lg:text-2xl text-green-100 max-w-3xl mx-auto">
              Explore our activities, facilities, and the farmers we serve through our visual journey
            </p>
          </div>
        </div>
      </section>

      {/* Filter Buttons */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-colors ${
                  activeCategory === category
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-green-50 hover:text-green-600'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Image Grid */}
      <section className="pb-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredImages.map((image) => (
              <div
                key={image.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => setSelectedImage(image.src)}
              >
                <div
                  className="h-64 bg-cover bg-center hover:scale-105 transition-transform duration-300"
                  style={{ backgroundImage: `url(${image.src})` }}
                ></div>
                <div className="p-4">
                  <p className="text-sm text-green-600 font-medium mb-1">{image.category}</p>
                  <p className="text-gray-800 font-medium">{image.alt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal for Full-Size Image */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 text-white hover:text-green-300 transition-colors"
            >
              <X className="h-8 w-8" />
            </button>
            <img
              src={selectedImage}
              alt="Full size view"
              className="max-w-full max-h-full rounded-lg"
            />
          </div>
        </div>
      )}

      {/* Note for Customization */}
      <section className="py-12 bg-green-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              A Glimpse Into Our Journey
            </h3>
            <p className="text-gray-600 leading-relaxed">
             Every photograph in this gallery tells the story of our farmers, their hard work, and the sustainable journey of UAPCL. From collective farming to natural practices, these moments capture the dedication and unity that power our mission of empowering agriculture and nurturing the land.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;